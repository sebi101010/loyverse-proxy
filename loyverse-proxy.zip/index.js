const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const TOKENS = {
  token1: '0c545852d10340549325fa3cddd3828d',
  token2: '463f457b16ac472185e0b2fb892c1188'
};

// Route proxy : /api/:account/*
app.get('/api/:account/*', async (req, res) => {
  const token = TOKENS[req.params.account];
  if (!token) return res.status(400).json({ error: 'Compte inconnu' });

  const path = '/' + req.params[0];
  const query = req.url.includes('?') ? req.url.substring(req.url.indexOf('?')) : '';
  const url = `https://api.loyverse.com/v1.0${path}${query}`;

  try {
    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Health check
app.get('/', (req, res) => res.json({ status: 'ok', service: 'loyverse-proxy' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Proxy running on port ${PORT}`));
